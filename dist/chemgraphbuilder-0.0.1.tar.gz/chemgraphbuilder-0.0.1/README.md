# ChemGraphBuilder
chemgraphbuilder is a Python package for transforming chemical data into knowledge graphs. Leveraging PubChem for data extraction and Neo4j for graph databases, it enables researchers to easily extract, process, and visualize complex chemical relationships with precision.
